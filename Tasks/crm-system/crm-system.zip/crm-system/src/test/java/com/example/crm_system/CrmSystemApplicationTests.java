package com.example.crm_system;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrmSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
